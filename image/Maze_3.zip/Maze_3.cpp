#include <iostream>
#include <conio.h>
#include <cstring>
#include <windows.h>
using namespace std;
string map1[10] = {"####################",
                   "#Y                 #",
                   "#                  #",
                   "#                  #",
                   "#                  #",
                   "#                  #",
                   "#                  #",
                   "#                  #",
                   "#                 X#",
                   "####################"};
void print(string maps[], int size, int x, int y) {
    system("cls");
    for(int i = 0; i < size; i++) {
        for(int j = 0; j < maps[i].size(); j++) {
            if(i == y && j == x) {
                cout << "Y";
            } else {
                cout << maps[i][j];
            }
        }
        cout << endl;
    }
    return;
}
void move(string maps[], int size) {
    int x, y;
	for(int i = 0; i < size; i++) {
        for(int j = 0; j < maps[i].size(); j++) {
            if(maps[i][j] == 'Y') {
                y = i;
                x = j;
                maps[i][j] = ' ';
                break;
            }
        }
    }
    while(true) {
        print(maps, size, x, y);
        char a = getch();
        if(a == 'w' || a == 'W') {
            if(maps[y - 1][x] != '#') {
                y--;
            }
        } else if(a == 's' || a == 'S') {
            if(maps[y + 1][x] != '#') {
                y++;
            }
        } else if(a == 'a' || a == 'A') {
            if(maps[y][x - 1] != '#') {
                x--;
            }
        } else if(a == 'd' || a == 'D') {
            if(maps[y][x + 1] != '#') {
                x++;
            }
        }
        if(maps[y][x] == 'X') {
            system("cls");
            cout << "��Ӯ��!" << endl;
            return;
        }
    }
    return;
}
int main() {
    move(map1, 10);
    return 0;
}
